package com.example.hyeonjun.p2pandroid;

import android.app.Activity;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.os.Bundle;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class MainActivity extends Activity {
    Button upbtn,downbtn;

    String filePath = Environment.getExternalStorageDirectory().toString() + "/p2pDownload";
    File downloadDir;
    static boolean thread_flag = false;


    String selectDownPath=null;

    Intent upintent, downintent;

    TextView txt_path;
    TextView txt_down_path;
    TextView myIP;

    //  WebView webView;

    String path, downWhere, IP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        upbtn=(Button) findViewById(R.id.upload);
        downbtn=(Button) findViewById(R.id.download);
        txt_path = (TextView) findViewById(R.id.txt_path);
        txt_down_path = (TextView) findViewById(R.id.txt_down_path);


        myIP =(TextView)findViewById(R.id.myIP);

        WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        int ip = wifiInfo.getIpAddress();
        String ipAddress = Formatter.formatIpAddress(ip);

        myIP.setText("My IP : " + ipAddress);


        upintent = new Intent(getApplicationContext(), UploadActivity.class);
        downintent = new Intent(getApplicationContext(), DownloadActivity.class);

        upbtn.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                startActivityForResult(upintent, 1);
            }
        });
        downbtn.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                startActivityForResult(downintent, 2);
            }
        });


        downloadDir = new File(filePath);
        if(!downloadDir.exists()){

            if(!downloadDir.mkdirs()){
                downloadDir = null;
            }
        }

        if(!thread_flag){
            new listenThread().start();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK){
            if(requestCode == 1){
                path = data.getExtras().getString("path");
                IP = data.getExtras().getString("IP");
                //    Toast.makeText(getApplicationContext(), "path: " + path + "\nIP: " + IP, Toast.LENGTH_LONG).show();
                txt_path.setText(path);

            }
            if(requestCode == 2){
                selectDownPath=data.getExtras().getString("path");
                //    downWhere=data.getExtras().getString("DownWhere");
                //txt_path.setText("다운로드 받을 파일 : " +path + "\n다운로드 받을 경로 ::: "+ downWhere);
                // txt_path.setText("다운로드 받을 경로 : " +path);
                txt_down_path.setVisibility(View.VISIBLE);
                txt_down_path.setText("Download Path : " + selectDownPath);
                //  filePath = selectDownPath;//사용자가 선택한 디렉토리로 경로변경
            }
        }
    }



    private class listenThread extends Thread{
        private ServerSocket serv_sock;
        private Socket clnt_sock;
        private final int PORT = 9900;
        @Override
        public void run(){
            Log.i("TestTestTest","listenThread run" );
            try {
                serv_sock = new ServerSocket(PORT);
            }catch(IOException e){
                e.printStackTrace();
            }
            while(true) {
                try {
                    clnt_sock = serv_sock.accept();
                    new downloadThread(clnt_sock,filePath).start();
                    Log.i("TestTestTest","connected Client" );
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class downloadThread extends Thread{
        private Socket socket;
        private String filePath;
        private File file;
        private FileOutputStream fileOutputStream;
        private BufferedOutputStream bufferedOutputStream;
        private DataInputStream dataInputStream;

        byte[] bytes;
        String str;
        public downloadThread(Socket socket, String filePath) {
            this.socket = socket;
            // this.filePath = filePath;
            if(selectDownPath != null){
                this.filePath=selectDownPath;
            }
            else{
                this.filePath = filePath;
            }

        }
        public void run(){
            bytes = new byte[1024];
            //byte[] bytes=null;
            int recv_len=0;
            Log.i("DownTestTestTest","downloadThread run" );

            try {
                dataInputStream = new DataInputStream(socket.getInputStream());
                str = dataInputStream.readUTF();

                String string = new String(str);
                //Log.i("DownThread : String Show", string);

                filePath = filePath +"/" +string;
                Log.i("?????어디에 다운???" ,  filePath);
                // filePath=string;
            }catch(Exception e) {
                Log.i("DownTestTestTest", "down EXCE");
                e.printStackTrace();
            }

            file = new File(filePath);

            if(!file.exists()) {
                try {
                    file.createNewFile();
                }catch(IOException e){
                    Log.i("DownTestTestTest", "down IOEXce");
                    e.printStackTrace();
                }
            }
            Log.i("DownTestTestTest",filePath);

            try {
                fileOutputStream = new FileOutputStream(file);
                bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
            }catch(FileNotFoundException e){
                e.printStackTrace();
            }

            while(true){
                try {
                    recv_len = dataInputStream.read(bytes);


                }catch(IOException e){
                    e.printStackTrace();
                    break;
                }
                if(recv_len == -1){
                    Log.i("+++++++++++", "recv_len == -1");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Download complete", Toast.LENGTH_LONG).show();
                        }

                    });

                    break;
                }


                Log.i("TestTestTest",recv_len +"");


                try {
                    bufferedOutputStream.write(bytes,0,recv_len);
                }catch(IOException e){
                    e.printStackTrace();


                    break;
                }

            }


            try {

                dataInputStream.close();
                //fileOutputStream.close();
                bufferedOutputStream.close();
                socket.close();
            }catch(IOException e){
                e.printStackTrace();
            }
        }

    }
}
