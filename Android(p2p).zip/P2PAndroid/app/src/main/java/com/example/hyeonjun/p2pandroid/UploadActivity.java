package com.example.hyeonjun.p2pandroid;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import android.content.Intent;
import java.net.Socket;
import java.net.UnknownHostException;

import java.util.ArrayList;

public class UploadActivity extends Activity{
    String mCurrent;
    String mRoot;
    TextView mCurrentTxt;
    ListView mFileList;
    ArrayAdapter<String> mAdapter;
    ArrayList<String> arFiles;

    String uppath;
    String path;

    EditText e_clntIP;

    String IP;
    Intent intent;
    String selectFIleName;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);

        e_clntIP = (EditText) findViewById(R.id.edit_clntIP);



        mCurrentTxt = (TextView)findViewById(R.id.current);
        mFileList = (ListView)findViewById(R.id.fileList);

        arFiles = new ArrayList<String>();

        mRoot= Environment.getExternalStorageDirectory().getAbsolutePath();
        mCurrent =mRoot;

        //어탭터 생성하고 연결
        mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arFiles);
        mFileList.setAdapter(mAdapter);//리스트뷰에 어댑터 연결
        mFileList.setOnItemClickListener(mItemClickListener);

        refreshFiles();

    }

    //리스트뷰 클릭 리스너
    AdapterView.OnItemClickListener mItemClickListener = new AdapterView.OnItemClickListener(){
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            path = "";
            String Name = arFiles.get(position);//클릭된 위치의 값을 가져옴

            //디렉토리이면
            if(Name.startsWith("[") && Name.endsWith("]")){
                Name = Name.substring(1, Name.length() - 1);//[]부분을 제거

            }
            //들어가기 위해 /와 터치한 파일 명을 붙여줌
            path = mCurrent +"/" +Name;
            File f = new File(path);//File 클래스 생성
            if(f.isDirectory()){ //디렉토리이면
                mCurrent = path;//현재를 path로 바꿔줌
                refreshFiles();
            }
            else{
                //Toast.makeText(UploadActivity.this, arFiles.get(position), Toast.LENGTH_LONG).show();
                Toast.makeText(UploadActivity.this, "파일: " + path + "   ///   경로: "+ mCurrent, Toast.LENGTH_LONG).show();
                selectFIleName=f.getName();
                //Log.i("UPLOAD!!!!select File name", selectFIleName);
            }
        }
    };

    //버튼 2개 클릭시
    public void mOnClick(View v){
        switch (v.getId()){
            case R.id.btnroot://루트로 가기
                if(mCurrent.compareTo(mRoot) != 0){
                    mCurrent = mRoot;
                    refreshFiles();
                }
                break;

            case R.id.btnup:
                if(mCurrent.compareTo(mRoot) != 0){
                    int end = mCurrent.lastIndexOf("/");
                    uppath = mCurrent.substring(0,end);
                    mCurrent  = uppath;
                    refreshFiles();

                }
                break;

            case R.id.btnselect:

                IP = e_clntIP.getText().toString();
                Intent intent = new Intent();
                Bundle extra = new Bundle();

                extra.putString("path", path);
                extra.putString("IP", IP);
                intent.putExtras(extra);

                //String IPaddr = e_clntIP.toString();
                String IPaddr = e_clntIP.getText().toString();
                /*mCurrent = mCurrent+"\r\n";
                path = path + "\r\n";*/
                new uploadThread(IPaddr,path, selectFIleName).start();

                Log.i("??WELL>>>>>>", IPaddr);
                Log.i("??WELL>>>>>>", mCurrent);
                Log.i("??WELL>>>>>>", path);



                UploadActivity.this.setResult(RESULT_OK, intent);
                UploadActivity.this.finish();

                break;
        }
    }

    void refreshFiles(){
        mCurrentTxt.setText(mCurrent);//
        arFiles.clear();
        File current = new File(mCurrent);
        String[] files = current.list();

        if(files != null){
            for (int i=0; i < files.length; i++){
                String path = mCurrent + "/" + files[i];
                String Name = "";

                File f = new File(path);
                if(f.isDirectory()){
                    Name = "[" + files[i] + "]";

                }
                else{
                    Name = files[i];
                }

                arFiles.add(Name);
            }
        }

        mAdapter.notifyDataSetChanged();
    }



    private class uploadThread extends Thread{
        private Socket socket;
        private int PORT = 9900;
        private String IP;
        private String path;
        private File file;
        private FileInputStream fileInputStream;
        private BufferedInputStream bufferedInputStream;
        private DataOutputStream dataOutputStream;
        private String selectFname;

        byte[] buf = new byte[1024];
        int recv_len;
        public uploadThread(String IP,String path,String selectFname){
            this.path = path;
            this.IP=IP;
            this.selectFname=selectFname;
        }

        @Override
        public void run() {
            Log.i("TestTestTest", "uploadThread run");
            try {
                socket = new Socket(IP, PORT);
                if(socket != null){
                    Log.i("TestTestTest", "complete");
                    Log.i("FILE INFORMATION" , "file name : "+ selectFname);
                    Log.i("FILE INFORMATION" , "path : " + path);
                }
                else
                {
                    Log.i("TestTestTest", "Fail");
                }
            }catch(UnknownHostException e){
                Log.i("TestTestTest", "Unerror");
                e.printStackTrace();
            }catch(IOException e){
                Log.i("TestTestTest", "IOerror");
                e.printStackTrace();
            }

            try {
                dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataOutputStream.writeUTF(selectFname);
            } catch (IOException e) {
                e.printStackTrace();
            }

            Log.i("TestTestTest",selectFname);
            Log.i("TestTestTest",path);
            try{
                fileInputStream = new FileInputStream(path);
                bufferedInputStream = new BufferedInputStream(fileInputStream);
            }catch(FileNotFoundException e){
                Log.i("TestTestTest","fileNotFound");
                e.printStackTrace();
            }

            while(true) {
                try {
                    recv_len = bufferedInputStream.read(buf);
                } catch (IOException e) {
                    e.printStackTrace();
                    break;
                }
                Log.i("TestTestTest",recv_len +"");
                if (recv_len == -1)
                    break;

                try {
                    dataOutputStream.write(buf, 0, recv_len);
                }catch(IOException e){
                    e.printStackTrace();
                }
            }
            try{
                bufferedInputStream.close();
                fileInputStream.close();
                dataOutputStream.close();
                socket.close();
            }catch(IOException e){
                e.printStackTrace();
            }
        }
    }
}