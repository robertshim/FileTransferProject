package com.example.hyeonjun.p2pandroid;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

public class DownloadActivity extends Activity {

    String mCurrent;
    String mRoot;
    TextView mCurrentTxt;

    TextView t_ClntIP;
    EditText e_ClntIP;


    ListView mFileList;
    ArrayAdapter<String> mAdapter;
    ArrayList<String> arFiles;

    String uppath;
    String path,  downWhere;

    LinearLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        layout = (LinearLayout)findViewById(R.id.ipvisible);
        layout.setVisibility(View.GONE);

        mCurrentTxt = (TextView)findViewById(R.id.current);
        mFileList = (ListView)findViewById(R.id.fileList);

        arFiles = new ArrayList<String>();

        mRoot= Environment.getExternalStorageDirectory().getAbsolutePath();
        mCurrent =mRoot;

        //어탭터 생성하고 연결
        mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arFiles);
        mFileList.setAdapter(mAdapter);//리스트뷰에 어댑터 연결
        mFileList.setOnItemClickListener(mItemClickListener);

        refreshFiles();

    }

    //리스트뷰 클릭 리스너
    AdapterView.OnItemClickListener mItemClickListener = new AdapterView.OnItemClickListener(){
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            path = "";
            String Name = arFiles.get(position);//클릭된 위치의 값을 가져옴

            //디렉토리이면
            if(Name.startsWith("[") && Name.endsWith("]")){
                Name = Name.substring(1, Name.length() - 1);//[]부분을 제거

            }
            //들어가기 위해 /와 터치한 파일 명을 붙여줌
            path = mCurrent +"/" +Name;
            File f = new File(path);//File 클래스 생성
            if(f.isDirectory()){ //디렉토리이면
                mCurrent = path;//현재를 path로 바꿔줌
                refreshFiles();
            }
            else{
                //Toast.makeText(UploadActivity.this, arFiles.get(position), Toast.LENGTH_LONG).show();
                Toast.makeText(DownloadActivity.this, "폴더: " + path + "   ///   경로: " + mCurrent, Toast.LENGTH_LONG).show();

            }
        }
    };

    //버튼 2개 클릭시
    public void mOnClick(View v){
        switch (v.getId()){
            case R.id.btnroot://루트로 가기
                if(mCurrent.compareTo(mRoot) != 0){
                    mCurrent = mRoot;
                    refreshFiles();
                }
                break;

            case R.id.btnup:
                if(mCurrent.compareTo(mRoot) != 0){
                    int end = mCurrent.lastIndexOf("/");
                    uppath = mCurrent.substring(0,end);
                    mCurrent  = uppath;
                    refreshFiles();

                }
                break;

            case R.id.btnselect:


                Intent intent = new Intent();
                Bundle extra = new Bundle();

                //extra.putString("DownWhere", path);
                extra.putString("path", path);
                intent.putExtras(extra);

                DownloadActivity.this.setResult(RESULT_OK, intent);
                DownloadActivity.this.finish();
              /*  Intent DownWhere = new Intent(this, WhereDownActivity.class);
                startActivityForResult(DownWhere, 3);*/

                break;
        }
    }

    void refreshFiles(){
        mCurrentTxt.setText(mCurrent);//
        arFiles.clear();
        File current = new File(mCurrent);
        String[] files = current.list();

        if(files != null){
            for (int i=0; i < files.length; i++){
                String path = mCurrent + "/" + files[i];
                String Name = "";

                File f = new File(path);
                if(f.isDirectory()){
                    Name = "[" + files[i] + "]";

                }
              /*  else{
                    Name = files[i];
                }*/

                arFiles.add(Name);
            }
        }

        mAdapter.notifyDataSetChanged();
    }

}